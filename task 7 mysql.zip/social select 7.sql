use social_name;
select * from users;
select * from alboms; 
select * from photos;
update users set nick_name = 'Unkown user 0023' where id = 4;
update users set is_deleted = true where id in (7,10,6);
update photos set is_deleted = true where id in (57,58,59,60,61,62,63,64);
update alboms set is_deleted = true where id in (15,16);
update comments set is_deleted = true where id in (6,4,9,15);
select photo_url from photos where is_deleted = false limit 0, 20 ;
select photo_url from photos where is_deleted = false limit 20, 40;
select * from photos where is_deleted = true;
select * from alboms where is_deleted = true;
select * from likes order by photo_id;
select 
	a.name as albom, 
    p.photo_url, 
    u.nick_name, 
    l.created_at 
from photos p
	join likes l on l.photo_id = p.id
	join users u on l.user_id = u.id
	join alboms a on p.albom_id = a.id 
    where u.is_deleted = false 
    and a.is_deleted = false
    and p.is_deleted = false
    order by nick_name desc;
select min(created_at), max(created_at), count(nick_name) from users where is_deleted = false;
select count(photo_url) from photos where is_deleted = false;
select count(photo_url) from photos where is_deleted = true;
select nick_name, ucase(nick_name) as uppercase, lcase(nick_name) as lowercase from users where  is_deleted = false;
select 
	m.message, 
	us.nick_name as sender, 
    ug.nick_name as getter, 
    sgm.created_at 
from messages m
	join send_get_messages sgm on sgm.message_id = m.id
    join users us on sgm.send_user_id = us.id
    join users ug on sgm.get_user_id = ug.id 
    and us.is_deleted = false
    and ug.is_deleted = false
    order by created_at;
select 
	m.message, 
	us.nick_name as sender, 
    ug.nick_name as getter, 
    sgm.created_at 
from messages m
	join send_get_messages sgm on sgm.message_id = m.id
    join users us on sgm.send_user_id = us.id
    join users ug on sgm.get_user_id = ug.id 
    and us.is_deleted = true
    #and ug.is_deleted = true
    order by created_at;
select 
	c.comment_text, 
    p.photo_url, 
    u.nick_name, 
    c.created_at 
from comments c
	join photos p on c.photo_id = p.id
    join users u on c.user_id = u.id 
    and u.is_deleted = false
	and c.is_deleted = false
    and p.is_deleted = false
    order by nick_name;
select 
	c.comment_text, 
    p.photo_url, 
    u.nick_name, 
    c.created_at 
from comments c
	join photos p on c.photo_id = p.id
    join users u on c.user_id = u.id 
    and c.is_deleted = true
    order by nick_name;
select nick_name from users where id in (3,9,5);
select photo_url, is_deleted from photos where photo_url like '%porn%';
select photo_url, is_deleted from photos where photo_url like 'www.__n_ai%';
select 
	a.name as albom,
    u.nick_name,
    a.created_at
from alboms a
	join users u on a.user_id = u.id where name is not null  order by albom;
select * from alboms where name regexp 'Summer [1900-2100]';
select * from users where nick_name regexp '^U';
select photo_url, created_at from photos where photo_url regexp 'summer|winter';
select 
	wee.nick_name as followee,
	wer.nick_name as follower,
    f.created_at
from follows f
	join users wee on f.followee_id = wee.id
    join users wer on f.follower_id = wer.id
    and wee.is_deleted = false
    and wer.is_deleted = false;
