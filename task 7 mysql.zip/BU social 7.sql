-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: social_name
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alboms`
--

DROP TABLE IF EXISTS `alboms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alboms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int NOT NULL,
  `is_deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `alboms_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alboms`
--

LOCK TABLES `alboms` WRITE;
/*!40000 ALTER TABLE `alboms` DISABLE KEYS */;
INSERT INTO `alboms` VALUES (1,'Summer 2018','2021-01-11 14:50:36',5,0),(2,'Winter 2019','2021-01-11 14:50:36',5,0),(3,'Friends','2021-01-11 14:50:36',1,0),(4,'Family','2021-01-02 19:45:04',1,0),(5,'My best friends','2020-12-02 11:54:06',2,0),(6,'My favorite dog','2021-01-11 14:50:36',2,0),(7,'Wishes','2021-01-11 14:50:36',3,0),(8,'Mom`s Birthday','2021-01-11 14:50:36',3,0),(9,'Nature','2020-10-29 10:12:58',4,0),(10,'Animals','2020-09-01 02:49:59',4,0),(11,'Usefull images','2021-01-11 14:50:36',6,0),(12,'Funny images','2021-01-11 14:50:36',6,0),(13,'Dark memes','2021-01-11 14:50:36',7,0),(14,'Memes','2021-01-11 14:50:36',7,0),(15,'Porn','2021-01-11 14:50:36',8,1),(16,'Hentai','2021-01-11 14:50:36',8,1),(17,'ghuirhiuershkjse','2020-11-09 13:54:09',9,0),(18,'dsgghshtjytjt','2021-01-11 14:50:36',9,0),(19,'Summer 1989','2019-06-18 13:07:44',10,0),(20,'Royal life','2021-01-11 14:50:36',10,0);
/*!40000 ALTER TABLE `alboms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `comment_text` varchar(255) NOT NULL,
  `photo_id` int NOT NULL,
  `user_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `is_deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `photo_id` (`photo_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`photo_id`) REFERENCES `photos` (`id`),
  CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` VALUES (1,'Nice!',2,1,'2021-01-11 14:50:36',0),(2,'Super!',3,4,'2021-01-11 14:50:36',0),(3,'I Love YOU',20,6,'2021-01-11 14:50:36',0),(4,'Nice cock!',70,8,'2021-01-11 14:50:36',1),(5,'Miss you',34,2,'2021-01-11 14:50:36',0),(6,'ahahhahahaha',16,1,'2021-01-11 14:50:36',1),(7,'LOL',34,5,'2021-01-11 14:50:36',0),(8,'Хачу майонеза',68,9,'2021-01-11 14:50:36',0),(9,'Суету навести ахота',41,5,'2021-01-11 14:50:36',1),(10,'А где Влад Бумага?',44,7,'2021-01-11 14:50:36',0),(11,'АХХХАХАХААХАХ',72,3,'2021-01-11 14:50:36',0),(12,'На твое сообщение пришел новый телефон, важное посмотри вдруг там что-то',42,6,'2021-01-11 14:50:36',0),(13,'Слава Україні!',55,1,'2021-01-11 14:50:36',0),(14,'Героям Слава!',55,4,'2021-01-11 14:50:36',0),(15,'дизлайк отписка',80,8,'2021-01-11 14:50:36',1),(16,'WOW!!! This is so cute!',45,8,'2021-01-11 14:50:36',0),(17,'Never mind',75,5,'2021-01-11 14:50:36',0),(18,'Nicht schlecht',65,7,'2021-01-11 14:50:36',0),(19,'Ich möchte etwas zu essen',69,4,'2021-01-11 14:50:36',0),(20,'Das ist gut',72,2,'2021-01-11 14:50:36',0),(21,'Was ist das? Ist das buch?',25,9,'2021-01-11 14:50:36',0),(22,'Keine Ahnung',58,9,'2021-01-11 14:50:36',0),(23,'Ja wohl',63,10,'2021-01-11 14:50:36',0);
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `follows`
--

DROP TABLE IF EXISTS `follows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `follows` (
  `follower_id` int NOT NULL,
  `followee_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`follower_id`,`followee_id`),
  KEY `followee_id` (`followee_id`),
  CONSTRAINT `follows_ibfk_1` FOREIGN KEY (`follower_id`) REFERENCES `users` (`id`),
  CONSTRAINT `follows_ibfk_2` FOREIGN KEY (`followee_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `follows`
--

LOCK TABLES `follows` WRITE;
/*!40000 ALTER TABLE `follows` DISABLE KEYS */;
INSERT INTO `follows` VALUES (1,2,'2021-01-11 14:50:36'),(1,4,'2021-01-11 14:50:36'),(1,10,'2021-01-11 14:50:36'),(2,1,'2021-01-11 14:50:36'),(2,5,'2021-01-11 14:50:36'),(3,1,'2021-01-11 14:50:36'),(4,3,'2021-01-11 14:50:36'),(5,6,'2021-01-11 14:50:36'),(5,7,'2021-01-11 14:50:36'),(5,8,'2021-01-11 14:50:36'),(6,5,'2021-01-11 14:50:36'),(7,4,'2021-01-11 14:50:36'),(8,1,'2021-01-11 14:50:36'),(10,2,'2021-01-11 14:50:36'),(10,3,'2021-01-11 14:50:36'),(10,7,'2021-01-11 14:50:36');
/*!40000 ALTER TABLE `follows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `likes`
--

DROP TABLE IF EXISTS `likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `likes` (
  `user_id` int NOT NULL,
  `photo_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`,`photo_id`),
  KEY `photo_id` (`photo_id`),
  CONSTRAINT `likes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `likes_ibfk_2` FOREIGN KEY (`photo_id`) REFERENCES `photos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `likes`
--

LOCK TABLES `likes` WRITE;
/*!40000 ALTER TABLE `likes` DISABLE KEYS */;
INSERT INTO `likes` VALUES (1,5,'2021-01-08 06:57:56'),(1,6,'2020-12-29 14:23:41'),(1,7,'2020-12-29 14:23:41'),(1,20,'2020-12-31 09:25:22'),(1,25,'2021-01-08 10:57:56'),(1,35,'2020-12-29 14:23:41'),(2,1,'2021-01-08 06:57:56'),(2,2,'2020-12-31 09:25:22'),(2,4,'2020-12-31 09:25:22'),(2,5,'2021-01-08 10:57:56'),(2,20,'2021-01-11 14:50:36'),(2,35,'2021-01-08 10:57:56'),(2,41,'2020-12-29 14:23:41'),(3,2,'2021-01-08 10:57:56'),(3,20,'2021-01-08 10:57:56'),(3,72,'2021-01-11 14:50:36'),(3,75,'2020-12-31 09:25:22'),(3,79,'2020-12-29 14:23:41'),(4,1,'2021-01-08 10:57:56'),(4,20,'2021-01-08 10:57:56'),(4,35,'2021-01-08 10:57:56'),(4,64,'2020-12-31 09:25:22'),(5,20,'2020-12-29 14:23:41'),(5,40,'2021-01-08 06:57:56'),(5,45,'2021-01-08 06:57:56'),(5,61,'2021-01-08 10:57:56'),(6,15,'2021-01-08 06:57:56'),(6,20,'2020-12-29 14:23:41'),(6,45,'2020-12-29 14:23:41'),(6,71,'2020-12-29 14:23:41'),(7,5,'2020-12-31 09:25:22'),(7,15,'2020-12-31 09:25:22'),(7,42,'2020-12-29 14:23:41'),(7,68,'2020-12-29 14:23:41'),(8,1,'2020-12-31 09:25:22'),(8,73,'2021-01-08 10:57:56'),(9,7,'2020-12-29 14:23:41'),(9,15,'2020-12-31 09:25:22'),(9,25,'2021-01-11 14:50:36'),(9,55,'2020-12-29 14:23:41'),(9,80,'2020-12-29 14:23:41'),(10,12,'2021-01-11 14:50:36'),(10,24,'2020-12-31 09:25:22'),(10,25,'2020-12-31 09:25:22'),(10,32,'2021-01-08 06:57:56');
/*!40000 ALTER TABLE `likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `message` text NOT NULL,
  `is_deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` VALUES (1,'Привіт',0),(2,'Привіт!',0),(3,'Як спарви?',0),(4,'Добре, а у тебе?',0),(5,'Добре',0),(6,'Погано',0),(7,'Могло бути й краще',0),(8,'Вітаю з Новим Роком!!!',0),(9,'і тебе',0),(10,'Дякую і тебе',0),(11,'Що нового в житті?',0),(12,'Да ось вирішив зайнятися програмуванням',0),(13,'ООО!',0),(14,'Це чудово!',0),(15,'Ну нехай щастить',0),(16,'Дякую',0),(17,'Вибач не можу зараз писати',0),(18,'Зрозумів',0),(19,'Чому?',0),(20,'Погнали катку в КС',0),(21,'Го, я создав',0),(22,'Мені в бравл старс випала легендарка',0),(23,'Хочу купити собі бравл пасс',0),(24,'Ну це корече мені треба бігти',0),(25,'До побачення',0),(26,'Пока',0);
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `photos`
--

DROP TABLE IF EXISTS `photos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `photos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `photo_url` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `albom_id` int NOT NULL,
  `is_deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `albom_id` (`albom_id`),
  CONSTRAINT `photos_ibfk_1` FOREIGN KEY (`albom_id`) REFERENCES `alboms` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `photos`
--

LOCK TABLES `photos` WRITE;
/*!40000 ALTER TABLE `photos` DISABLE KEYS */;
INSERT INTO `photos` VALUES (1,'www.summerfoto2018','2021-01-11 14:50:36',1,0),(2,'www.summerfoto2018(1)','2021-01-11 14:50:36',1,0),(3,'www.summerfoto2018(2)','2021-01-11 14:50:36',1,0),(4,'www.summerfoto2018(3)','2021-01-11 14:50:36',1,0),(5,'www.winterfoto2019','2021-01-11 14:50:36',2,0),(6,'www.winterfoto2019(1)','2021-01-11 14:50:36',2,0),(7,'www.winterfoto2019(2)','2021-01-11 14:50:36',2,0),(8,'www.winterfoto2019(3)','2021-01-11 14:50:36',2,0),(9,'www.friends','2021-01-11 14:50:36',3,0),(10,'www.friends(1)','2021-01-11 14:50:36',3,0),(11,'www.friends(2)','2021-01-11 14:50:36',3,0),(12,'www.friends(3)','2021-01-11 14:50:36',3,0),(13,'www.family','2021-01-11 14:50:36',4,0),(14,'www.family(1)','2021-01-11 14:50:36',4,0),(15,'www.family(2)','2021-01-11 14:50:36',4,0),(16,'www.family(3)','2021-01-11 14:50:36',4,0),(17,'www.mybf','2021-01-11 14:50:36',5,0),(18,'www.mybf(1)','2021-01-11 14:50:36',5,0),(19,'www.mybf(2)','2021-01-11 14:50:36',5,0),(20,'www.mybf(3)','2021-01-11 14:50:36',5,0),(21,'www.myfd','2021-01-11 14:50:36',6,0),(22,'www.myfd(1)','2021-01-11 14:50:36',6,0),(23,'www.myfd(2)','2021-01-11 14:50:36',6,0),(24,'www.myfd(3)','2021-01-11 14:50:36',6,0),(25,'www.wishes','2021-01-11 14:50:36',7,0),(26,'www.wishes(1)','2021-01-11 14:50:36',7,0),(27,'www.wishes(2)','2021-01-11 14:50:36',7,0),(28,'www.wishes(3)','2021-01-11 14:50:36',7,0),(29,'www.momsbd','2021-01-11 14:50:36',8,0),(30,'www.momsbd(1)','2021-01-11 14:50:36',8,0),(31,'www.momsbd(2)','2021-01-11 14:50:36',8,0),(32,'www.momsbd(3)','2021-01-11 14:50:36',8,0),(33,'www.nature','2021-01-11 14:50:36',9,0),(34,'www.nature(1)','2021-01-11 14:50:36',9,0),(35,'www.nature(2)','2021-01-11 14:50:36',9,0),(36,'www.nature(3)','2021-01-11 14:50:36',9,0),(37,'www.animals','2021-01-11 14:50:36',10,0),(38,'www.animals(1)','2021-01-11 14:50:36',10,0),(39,'www.animals(2)','2021-01-11 14:50:36',10,0),(40,'www.animals(3)','2021-01-11 14:50:36',10,0),(41,'www.useimg','2021-01-11 14:50:36',11,0),(42,'www.useimg(1)','2021-01-11 14:50:36',11,0),(43,'www.useimg(2)','2021-01-11 14:50:36',11,0),(44,'www.useimg(3)','2021-01-11 14:50:36',11,0),(45,'www.funnyig','2021-01-11 14:50:36',12,0),(46,'www.funnyig(1)','2021-01-11 14:50:36',12,0),(47,'www.funnyig(2)','2021-01-11 14:50:36',12,0),(48,'www.funnyig(3)','2021-01-11 14:50:36',12,0),(49,'www.darkmemes','2021-01-11 14:50:36',13,0),(50,'www.darkmemes(1)','2021-01-11 14:50:36',13,0),(51,'www.darkmemes(2)','2021-01-11 14:50:36',13,0),(52,'www.darkmemes(3)','2021-01-11 14:50:36',13,0),(53,'www.memes','2021-01-11 14:50:36',14,0),(54,'www.memes(1)','2021-01-11 14:50:36',14,0),(55,'www.memes(2)','2021-01-11 14:50:36',14,0),(56,'www.memes(3)','2021-01-11 14:50:36',14,0),(57,'www.porn','2021-01-11 14:50:36',15,1),(58,'www.porn(1)','2021-01-11 14:50:36',15,1),(59,'www.porn(2)','2021-01-11 14:50:36',15,1),(60,'www.porn(3)','2021-01-11 14:50:36',15,1),(61,'www.hentai','2021-01-11 14:50:36',16,1),(62,'www.hentai(1)','2021-01-11 14:50:36',16,1),(63,'www.hentai(2)','2021-01-11 14:50:36',16,1),(64,'www.hentai(3)','2021-01-11 14:50:36',16,1),(65,'www.ffdgdg','2021-01-11 14:50:36',17,0),(66,'www.ffdgdg(1)','2021-01-11 14:50:36',17,0),(67,'www.ffdgdg(2)','2021-01-11 14:50:36',17,0),(68,'www.ffdgdg(3)','2021-01-11 14:50:36',17,0),(69,'www.kjgghg','2021-01-11 14:50:36',18,0),(70,'www.kjgghg(1)','2021-01-11 14:50:36',18,0),(71,'www.kjgghg(2)','2021-01-11 14:50:36',18,0),(72,'www.kjgghg(3)','2021-01-11 14:50:36',18,0),(73,'www.summer1989','2021-01-11 14:50:36',19,0),(74,'www.summer1989(1)','2021-01-11 14:50:36',19,0),(75,'www.summer1989(2)','2021-01-11 14:50:36',19,0),(76,'www.summer1989(3)','2021-01-11 14:50:36',19,0),(77,'www.royallife','2021-01-11 14:50:36',20,0),(78,'www.royallife(1)','2021-01-11 14:50:36',20,0),(79,'www.royallife(2)','2021-01-11 14:50:36',20,0),(80,'www.royallife(3)','2021-01-11 14:50:36',20,0);
/*!40000 ALTER TABLE `photos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `send_get_messages`
--

DROP TABLE IF EXISTS `send_get_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `send_get_messages` (
  `send_user_id` int NOT NULL,
  `get_user_id` int NOT NULL,
  `message_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`send_user_id`,`get_user_id`,`message_id`),
  KEY `get_user_id` (`get_user_id`),
  KEY `message_id` (`message_id`),
  CONSTRAINT `send_get_messages_ibfk_1` FOREIGN KEY (`send_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `send_get_messages_ibfk_2` FOREIGN KEY (`get_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `send_get_messages_ibfk_3` FOREIGN KEY (`message_id`) REFERENCES `messages` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `send_get_messages`
--

LOCK TABLES `send_get_messages` WRITE;
/*!40000 ALTER TABLE `send_get_messages` DISABLE KEYS */;
INSERT INTO `send_get_messages` VALUES (1,3,14,'2020-12-31 22:21:20'),(1,3,15,'2020-12-31 22:21:22'),(1,3,18,'2020-12-31 22:21:21'),(1,3,20,'2020-12-31 22:21:17'),(1,8,1,'2020-12-31 22:21:14'),(1,8,20,'2020-12-31 22:21:15'),(2,6,1,'2021-01-10 12:54:55'),(2,6,3,'2021-01-10 12:54:57'),(2,6,19,'2021-01-10 12:54:59'),(3,1,17,'2020-12-31 22:21:18'),(3,1,22,'2020-12-31 22:21:19'),(4,7,10,'2020-12-31 22:06:35'),(6,2,2,'2021-01-10 12:54:56'),(6,2,6,'2021-01-10 12:54:58'),(6,2,17,'2021-01-10 12:55:00'),(7,4,2,'2020-12-31 22:04:39'),(7,4,8,'2020-12-31 22:04:59'),(7,9,8,'2020-12-31 22:06:52'),(8,1,13,'2020-12-31 22:21:16'),(9,7,9,'2020-12-31 22:21:13');
/*!40000 ALTER TABLE `send_get_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nick_name` varchar(40) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `is_deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `nick_name` (`nick_name`),
  KEY `idx_nick_name` (`nick_name`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Unga-Bunga69','2021-01-11 14:50:36',0),(2,'Akukaracha','2021-01-11 14:50:36',0),(3,'Barak Obama','2020-04-15 13:25:59',0),(4,'Unkown user 0023','2021-01-11 14:50:36',0),(5,'Hausemaster','2021-01-04 00:39:01',0),(6,'Jordan2004','2021-01-11 14:50:36',1),(7,'Akuna-Matata','2021-01-11 14:50:36',1),(8,'-MyXa_B_KeDaX-','2021-01-11 14:50:36',0),(9,'True_Minecrafter','2020-01-02 16:45:19',0),(10,'Pink_Pony228','2020-01-04 08:45:49',1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-01-11 17:08:11
