drop database if exists die_bibliothek;
create database die_bibliothek char set utf8;
use die_bibliothek;

create table category(
	id int not null primary key auto_increment,
    name varchar(40) not null unique
);

create table author(
	id int not null primary key auto_increment,
    first_name varchar(45) not null,
    last_name varchar(45) not null,
    email varchar(80) not null unique,
    adress varchar(200) not null,
    birthday date default '1999-03-29'
);

create table book(
	id int not null primary key auto_increment,
    name varchar(120) not null unique,
    price decimal (8,2) not null,
    isbn varchar(20) not null unique,
    category_id int not null,
    author_id int not null
);

alter table book add foreign key (category_id)
	references category(id);
alter table book add foreign key (author_id)
	references author(id);