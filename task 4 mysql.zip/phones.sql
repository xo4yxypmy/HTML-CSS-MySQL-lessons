drop database if exists phones;
create database phones char set utf8;
use phones;

create table manufacturer(
	id int not null primary key auto_increment,
    name varchar(50) not null unique,
    description text
);

create table camera(
	id int not null primary key auto_increment,
    name varchar(40) not null,
    description text
);
    
create table main_processor(
	id int not null primary key auto_increment,
    name varchar(40) not null unique,
    description text
);
    
create table battery(
	id int not null primary key auto_increment,
	name varchar(40) not null,
	description text
);

create table phone_memory(
	id int not null primary key auto_increment,
    name varchar(40) not null
);

create table display(
	id int not null primary key auto_increment,
    name varchar(40) not null,
    description  text
);

create table os(
	id int not null primary key auto_increment,
    name varchar(40) not null unique,
    description text
);
    
create table model(
	id int not null primary key auto_increment,
    name varchar(40) not null unique,
    manufacturer_id int not null,
    camera_id int not null,
    main_processor_id int not null,
    battery_id int not null,
    phone_memory_id int not null,
    display_id int not null,
    os_id int not null
);

alter table model add foreign key (manufacturer_id)
	references manufacturer(id);
alter table model add foreign key (camera_id)
	references camera(id);
alter table model add foreign key (main_processor_id)
	references main_processor(id);
alter table model add foreign key (battery_id)
	references battery(id);
alter table model add foreign key (phone_memory_id)
	references phone_memory(id);
alter table model add foreign key (display_id)
	references display(id);
alter table model add foreign key (os_id)
	references os(id);