select database();
use library;

select * from book;
update book set author_surname = 'Sapkowski' where id = 3;
update book set author_surname = 'Dickens' where isbn = 'SQ-5656';
select count(author_awards) from book where author_awards is not null;
select name_book, description_book, category, author_name, author_surname, qty_pages, price from book
	where qty_pages = (select min(qty_pages) from book);
select name_book, description_book, category, author_name, author_surname, qty_pages, price from book
	where qty_pages = (select max(qty_pages) from book);
select avg(price) from book;
select sum(qty_in_stock) from book where category = 'Історія';
select min(price) from book;
select name_book, description_book, category, author_name, author_surname, qty_pages, price, qty_in_stock from book
	where price = (select min(price) from book);
select name_book, price from book order by name_book;
select * from book order by date_book limit 5, 5;
select * from book order by date_book limit 10, 6;
select * from book where name_book like '%q.r%';
select * from book where author_awards like '__t b__%';
select * from book where isbn like 'SQ-_22_';
select * from book where price between 50 and 120 order by price;
select * from book where price not between 200 and 600 order by price;
delete from book where id = 24;
delete from book where isbn = 'SQ-5982';
set sql_safe_updates = 0;
delete from book where name_book = '1984'; # чомусь при видаленні через name воно вимагало відключення safe режиму, чи не могли б ви пояснити чому так, якщо я задав умову where
set sql_safe_updates = 1;