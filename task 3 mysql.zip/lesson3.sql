drop database library;
create database library char set utf8;
use library;

create table book(
	id int not null primary key auto_increment,
	name_book varchar (120) not null,
    description_book varchar (255) default 'Опис відсутній',
    date_book date not null default '2018-01-01',
    author_name varchar (45) not null,
    author_surname varchar (45) not null,
    author_email varchar (50) not null unique,
    category varchar (30) not null,
    isbn varchar (20) not null unique,
    qty_pages smallint not null,
    author_age smallint not null,
    author_awards varchar (120),
    price decimal (8, 4) not null,  # в завдані не вказано про створенняя даного поля
    qty_in_stock smallint default 0 # в завдані 7 не вказано конкретно суму чого потрібно порахувати
);

insert into book(name_book, description_book, date_book, author_name, author_surname, author_email, category, isbn, qty_pages, author_age, author_awards, price, qty_in_stock)
	values
		('S.P.Q.R', 'Історія Древнього Риму', default, 'Мері', 'Бірд', 'mery.bird@gmail.com', 'Історія', 'SQ-0896', 405, 70, 'Realy History Awards 2010', 400.00, 50),
        ('1984', 'Старший брат пильнує за тобою', default, 'Джордж', 'Орвелл', 'dj.orvel84@gamil.com', 'Драма', 'SQ-1984', 250, 65, 'AntiUSSR-Author 1960', 149.99, 60),
        ('Відьмак', default, '1993-06-30', 'Анджей', 'Сапковський', 'andzj.sapkov@gmail.com', 'Фентезі', 'SQ-0013', 300, 75, 'Super Fantasy Awards 2015', 145.88, default),
        ('Наодинці з собою', default, '2018-05-24', 'Марк', 'Аврелій', 'mark.avrelii@gmail.com', 'Історія', 'SQ-5489', 267, 55, null, 96.50, 25),
        ('На західному фронті без змін', 'Події відбуваються за часів Першої світової війни', default, 'Еріх Марія', 'Ремарк', 'maria.remark@gmail.com', 'Художня література', 'SQ-6987', 351, 90, 'Realy History Awards 1950', 200.00, 60),
        ('Три товариша', default,'2015-09-10','Еріх Марія', 'Ремарк', 'maria.remark1@gamil.com', 'Драма', 'SQ-9843', 150, 90, 'Best Author for school 2000', 300.00, 175),
        ('Хамелеон', default,'2010-03-25','Антон', 'Чехов', 'anton.chehoff@gmail.com', 'Шкільна література', 'SQ-5982', 321, 70, 'Not Bad Awards 1998', 89.99,default),
        ('Божествена комедія', 'Поет зображає драматичну долю людської душі', default, 'Данте', 'Алігєрі', 'dante.aligeri@gmail.com', 'Комедія', 'SQ-7115', 634, 54, null, 100.00,default),
        ('Айвенго','Пригоди Айвенго',  default,'Вальтер', 'Скот', 'valter.skottt@gmail.com', 'Шкільна література', 'SQ-5687', 557, 62, 'May be Awards 3000', 250.00,56),
        ('Іліада', default,'2013-12-07','Гомер', 'Відсутнє', 'gomer@gmail.com', 'Шкільна література', 'SQ-9133', 853, 45, null, 899.99,78),
        ('Різдвяна пісня в прозі','Якась  книжка про Різдво','2015-08-12','Чарльз','Дікенс','charls.dikens@gmail.com','Дитяча література','SQ-5656', 356, 58,'Best Christmas Book 2012', 75.50,201),
        ('Гаррі Поттер і таємна кімната','Пригоди Гаррі Поттера','2000-12-10','Джоан','Роулінг','djoan.rouling1@gmail.com','Дитяча література','SQ-5698', 345, 60,'Great Children Story 2001', 275.85,32),
        ('Гаррі Поттер і філософський камінь','Пригоди Гаррі Поттера','2001-12-10','Джоан','Роулінг','djoan.rouling2@gmail.com','Дитяча література','SQ-5228', 265, 60,'Great Children Story 2002', 300.00,12),
        ('Гаррі Поттер і орден Фенікса','Пригоди Гаррі Поттера','2002-12-10','Джоан','Роулінг','djoan.rouling3@gmail.com','Дитяча література','SQ-4698', 195, 60,'Great Children Story 2003', 250.50,54),
        ('Гаррі Поттер і прокляте дитя','Пригоди Гаррі Поттера','2003-12-10','Джоан','Роулінг','djoan.rouling4@gmail.com','Дитяча література','SQ-5229', 405, 60,'Great Children Story 2004', 305.50,5),
        ('Повісті про хазар, буртасах, болгарах, мадярах, славянах та русах',default,'2012-05-26','Абу-Алі Ахмед','Бен Омар Ібн-Даст','abu.ali.ibn.omar@gmail.com','Історія','SQ-1133', 215, 69, null, 189.60,9),
        ('Канони лікарської науки','Книга про медицину','2010-10-10','Авіценна','Відсутнє','avicenna@gmail.com','Медицина','SQ-9987', 128, 60,'Medical book №1 2008', 70.20,default),
        ('Ніч у Лісабоні',default,'1998-06-03','Еріх Марія','Ремарк','maria.remark2@gmail.com','Проза','SQ-1167', 288, 90,'Not Bad Awards 2020', 90.00,7),
        ('Чорний обеліск',default,'1989-07-16','Еріх Марія','Ремарк','maria.remark3@gmail.com','Проза','SQ-2467', 212, 90,'Not Bad Awards 2015', 99.99,default),
        ('Тріумфальна арка',default,'1988-06-03','Еріх Марія','Ремарк','maria.remark4@gmail.com','Проза','SQ-9991', 288, 90,'Not Bad Awards 2000', 155.50,98),
        ('Крістіан Діор','Парфюми','2016-03-26','Франсуа-Олівє','Руссо','fransua.olive@gmail.com','Сучасна література','SQ-6611', 232, 78,null, 90.60,61),
        ('Так мовив Зратустра','Філософія Фрідріха Ніцше','1883-11-29','Фрідріх','Ніцше','fridrich.nizsche@gmail.com','Філософія','SQ-1666', 253, 76,null, 400.00,61),
        ('По ту сторону добра та зла','Філософія Фрідріха Ніцше','2013-11-19','Фрідріх','Ніцше','fridrich.nizsche1@gmail.com','Філософія','SQ-2266', 544, 76,null, 555.50,2),
        ('Пригоди Олівера Твіста',default,'2012-08-12','Чарльз','Дікенс','charls.dikens1@gmail.com','Дитяча література','SQ-5116', 186, 58,'Best Christmas Book 2003', 150.50,default),
        ('Девід Коперфілд',default,'2000-06-17','Чарльз','Дікенс','charls.dikens2@gmail.com','Дитяча література','SQ-7126', 259, 58,'Best Christmas Book 2009', 60.50,4);
