drop database if exists die_bibliothek;
create database die_bibliothek char set utf8;
use die_bibliothek;

create table category(
	id int not null primary key auto_increment,
    name varchar(40) not null unique
);

create table author(
	id int not null primary key auto_increment,
    first_name varchar(45) not null,
    last_name varchar(45) not null,
    email varchar(80) not null unique,
    adress varchar(200) not null,
    birthday date default '1999-03-29'
);

create table book(
	id int not null primary key auto_increment,
    name varchar(120) not null unique,
    price decimal (8,2) not null,
    isbn varchar(20) not null unique,
    category_id int not null
);

alter table book add foreign key (category_id)
	references category(id);
    
create table author_book(
	author_id int not null,
    book_id int not null
);

alter table author_book add foreign key (author_id)
	references author(id);
alter table author_book add foreign key (book_id)
	references book(id);

insert into category(name) values
	('Історія'),
    ('Українська література'),
    ('Зарубіжна література'),
    ('Класика');

insert into author(first_name, last_name, email, adress, birthday) values
	('Тарас','Шевченко','kobzar@gmail.com','Адреса відсутня','1814-09-03'),
    ('Мері','Берд','mary.beard@gmail.com','Велика Британія, Лондон, вул. Леніна 23','1955-01-01'),
    ('Дмитро','Капранов','dmytro.kapranov@gmail.com','Україна, Київ, вул. Така-то 65 ','1967-08-24'),
    ('Віталій','Капранов','vitaliy.kapranov@gmail.com','Україна, Київ, вул. Якась там 99','1967-08-24'),
    ('Анджей','Сапковський','andrzej@gmail.com','Польща, Лодзь, вул. Невідома 11','1948-06-21');

insert into book(name, price, isbn, category_id) values
	('Відьмак',190.00,'FB-0137',3),
    ('Кобзар',110.50,'NB-9002',2),
    ('S.P.Q.R.',250.00,'FB-0881',1),
    ('Мальована історія Незалежності України',150.00,'NB-8110',1),
    ('Заповіт',180.70,'NB-7899',2);

insert into author_book(author_id, book_id) values
	(1, 2),
    (1, 5),
    (2, 3),
    (3, 4),
    (4, 4),
    (5, 1);