drop database if exists phones;
create database phones char set utf8;
use phones;

create table manufacturer(
	id int not null primary key auto_increment,
    name varchar(50) not null unique,
    description text
);

create table camera(
	id int not null primary key auto_increment,
    name varchar(40) not null,
    description text
);
    
create table main_processor(
	id int not null primary key auto_increment,
    name varchar(40) not null unique,
    description text
);
    
create table battery(
	id int not null primary key auto_increment,
	name varchar(40) not null
);

create table phone_memory(
	id int not null primary key auto_increment,
    name varchar(40) not null
);

create table display(
	id int not null primary key auto_increment,
    name varchar(40) not null,
    description  text
);

create table os(
	id int not null primary key auto_increment,
    name varchar(40) not null unique,
    description text
);
    
create table model(
	id int not null primary key auto_increment,
    name varchar(40) not null unique,
    price decimal (8, 2),
    manufacturer_id int not null,
    camera_id int not null,
    main_processor_id int not null,
    battery_id int not null,
    phone_memory_id int not null,
    display_id int not null,
    os_id int not null
);

alter table model add foreign key (manufacturer_id)
	references manufacturer(id);
alter table model add foreign key (camera_id)
	references camera(id);
alter table model add foreign key (main_processor_id)
	references main_processor(id);
alter table model add foreign key (battery_id)
	references battery(id);
alter table model add foreign key (phone_memory_id)
	references phone_memory(id);
alter table model add foreign key (display_id)
	references display(id);
alter table model add foreign key (os_id)
	references os(id);
    
insert into manufacturer(name, description) values
	('Google', 'Who does not know Google???'),
    ('Apple', 'Who does not know Apple???'),
    ('Samsung', 'Korean Titan'),
    ('Xiaomi', 'Chinese Titan'),
    ('Oppo', 'Chinese Titan'),
    ('Sony', 'Japanese Titan');

insert into camera (name, description) values
	('64MP', 'Camera from Sony'),
    ('28MP', 'Camera from Samsung'),
    ('64MP', 'Camera from Samsung'),
    ('108MP', 'Camera from Motorola');

insert into main_processor(name, description) values
	('Snapdragon 835', 'Some details'),
    ('Snapdragon 625', 'Some details'),
    ('Exynos 990', 'Some details'),
    ('Exynos 7 Octa(7420)', 'Some details'),
    ('A11', 'Some details');

insert into battery (name) values
	('3500 mAh'),
    ('4000 mAh'),
    ('5000 mAh');

insert into phone_memory(name) values 
	('64GB'),
    ('128GB'),
    ('256GB'),
    ('512GB');

insert into display (name, description) values
	('AMOLED', 'AMOLED information'),
    ('IPS', 'IPS information');

insert into os (name, description) values
	('Android', 'One of the most popular OS'),
    ('IOS', 'One of the most popular OS');

insert into model(name, price, manufacturer_id, camera_id, main_processor_id, battery_id, phone_memory_id, display_id, os_id) values
	('Redmi Note 9 Pro', 10000.00, 4, 1, 1, 3, 2, 2, 1),
    ('iPhone 8', 25000.00, 2, 4, 5, 1, 3, 1, 2),
    ('Samsung A11', 15000.00, 3, 2, 3, 2, 4, 1, 1);