select * from book;
select * from author;

select 
	b.name,
    b.price,
    b.isbn,
    c.name as category,
    a.first_name,
    a.last_name,
    a.email,
    a.adress,
    a.birthday
from book b
join author_book ab on ab.book_id = b.id
join author a on ab.author_id = a.id
join category c on b.category_id = c.id;