select * from model;

select 
	m.name as model,
    m.price,
    mf.name as manufacturer,
    mf.description as manufacturer_info,
    c.name as camera,
    mp.name as main_processor,
    b.name as battery,
    d.name as display,
    d.description as display_info,
    os.name as os
from model m
join manufacturer mf on m.manufacturer_id = mf.id
join camera c on m.camera_id = c.id
join main_processor mp on m.main_processor_id = mp.id
join battery b on m.battery_id = b.id
join phone_memory pm on m.phone_memory_id = pm.id
join display d on m.display_id = d.id
join os on m.os_id = os.id;