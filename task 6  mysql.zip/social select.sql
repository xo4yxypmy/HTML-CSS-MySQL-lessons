use social_name;
select * from users;
select * from alboms; 
select * from photos;
select photo_url from photos limit 0, 20;
select photo_url from photos limit 20, 40;
select * from likes order by photo_id;
select 
	a.name as albom, 
    p.photo_url, 
    u.nick_name, 
    l.created_at 
from photos p
	join likes l on l.photo_id = p.id
	join users u on l.user_id = u.id
	join alboms a on p.albom_id = a.id order by nick_name desc;
select min(created_at), max(created_at), count(nick_name) from users;
select count(photo_url) from photos;
select nick_name, ucase(nick_name) as uppercase, lcase(nick_name) as lowercase from users;
select 
	m.message, 
	us.nick_name as sender, 
    ug.nick_name as getter, 
    sgm.created_at 
from messages m
	join send_get_messages sgm on sgm.message_id = m.id
    join users us on sgm.send_user_id = us.id
    join users ug on sgm.get_user_id = ug.id order by created_at;
select 
	c.comment_text, 
    p.photo_url, 
    u.nick_name, 
    c.created_at 
from comments c
	join photos p on c.photo_id = p.id
    join users u on c.user_id = u.id order by nick_name;
select nick_name from users where id in (3,9,5);
select photo_url from photos where photo_url like '%porn%';
select photo_url from photos where photo_url like 'www.__n_ai%';
update users set nick_name = 'Unkown user 0023' where id = 4;
select 
	a.name as albom,
    u.nick_name,
    a.created_at
from alboms a
	join users u on a.user_id = u.id where name is not null order by albom;
select * from alboms where name regexp 'Summer [1900-2100]';
select * from users where nick_name regexp '^U';
select photo_url, created_at from photos where photo_url regexp 'summer|winter';
