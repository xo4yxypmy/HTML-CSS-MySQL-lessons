drop database if exists social_name;
create database social_name char set utf8;
use social_name;

create table users(
	id int not null primary key auto_increment,
    nick_name varchar (40) not null unique,
    created_at timestamp default now()
);

create table alboms(
	id int not null primary key auto_increment,
    name varchar(40) not null,
    created_at timestamp default now(),
    user_id int not null
);

create table photos(
	id int not null primary key auto_increment,
    photo_url varchar(255) not null,
    created_at timestamp default now(),
    albom_id int not null
);

create table messages(
	id int not null primary key auto_increment,
    message text not null
);

create table send_get_messages(
	send_user_id int not null,
    get_user_id int not null,
    message_id int not null,    
    created_at timestamp default now(),
    primary key (send_user_id, get_user_id, message_id)
);

create table likes(
	user_id int not null,
    photo_id int not null,
    created_at timestamp default now(),
    primary key (user_id, photo_id)
);

create table follows(
	follower_id int not null,
    followee_id int not null,
    created_at timestamp default now(),
    primary key (follower_id, followee_id)
);

create table comments(
	id int not null primary key auto_increment,
    comment_text varchar(255) not null,
    photo_id int not null,
    user_id int not null,
    created_at timestamp default now()
);

create index idx_nick_name on users (nick_name);

alter table alboms add foreign key (user_id) references users(id);
alter table photos add foreign key (albom_id) references alboms(id);
alter table send_get_messages add foreign key (send_user_id) references users(id);
alter table send_get_messages add foreign key (get_user_id) references users(id);
alter table send_get_messages add foreign key (message_id) references messages(id);
alter table likes add foreign key (user_id) references users(id);
alter table likes add foreign key (photo_id) references photos(id);
alter table follows add foreign key (follower_id) references users(id);
alter table follows add foreign key (followee_id) references users(id);
alter table comments add foreign key (photo_id) references photos(id);
alter table comments add foreign key (user_id) references users(id);

insert into users (nick_name, created_at) values ('Unga-Bunga69', default), ('Akukaracha', default), ('Barak Obama', '2020-04-15 16:25:59'), ('Попа_Бабуїна', default), ('Hausemaster', '2021-01-04 02:39:01'), ('Jordan2004', default), ('Akuna-Matata', default), ('-MyXa_B_KeDaX-', default), ('True_Minecrafter', '2020-01-02 18:45:19'), ('Pink_Pony228', '2020-01-04 10:45:49'); 
insert into alboms (name, created_at, user_id) values ('Summer 2018', default, 5), ('Winter 2019', default, 5), ('Friends', default, 1), ('Family', '2021-01-02 21:45:04', 1), ('My best friends', '2020-12-02 13:54:06', 2), ('My favorite dog', default, 2), ('Wishes', default, 3), ('Mom`s Birthday', default, 3), ('Nature', '2020-10-29 12:12:58', 4), ('Animals', '2020-09-01 05:49:59', 4), ('Usefull images', default, 6), ('Funny images', default, 6), ('Dark memes', default, 7), ('Memes', default, 7), ('Porn', default, 8), ('Hentai', default, 8), ('ghuirhiuershkjse', '2020-11-09 15:54:09', 9), ('dsgghshtjytjt', default, 9), ('Summer 1989', '2019-06-18 16:07:44', 10), ('Royal life', default, 10);
insert into photos (photo_url, created_at, albom_id) values ('www.summerfoto2018', default, 1), ('www.summerfoto2018(1)', default, 1), ('www.summerfoto2018(2)', default, 1), ('www.summerfoto2018(3)', default, 1), ('www.winterfoto2019', default, 2), ('www.winterfoto2019(1)', default, 2),('www.winterfoto2019(2)', default, 2),('www.winterfoto2019(3)', default, 2), ('www.friends', default, 3),('www.friends(1)', default, 3),('www.friends(2)', default, 3),('www.friends(3)', default, 3),('www.family', default, 4),('www.family(1)', default, 4),('www.family(2)', default, 4),('www.family(3)', default, 4),('www.mybf', default, 5),('www.mybf(1)', default, 5),('www.mybf(2)', default, 5),('www.mybf(3)', default, 5), ('www.myfd', default, 6), ('www.myfd(1)', default, 6), ('www.myfd(2)', default, 6), ('www.myfd(3)', default, 6), ('www.wishes', default, 7),('www.wishes(1)', default, 7),('www.wishes(2)', default, 7),('www.wishes(3)', default, 7),('www.momsbd', default, 8),('www.momsbd(1)', default, 8),('www.momsbd(2)', default, 8),('www.momsbd(3)', default, 8), ('www.nature', default, 9),('www.nature(1)', default, 9),('www.nature(2)', default, 9),('www.nature(3)', default, 9),('www.animals', default, 10),('www.animals(1)', default, 10),('www.animals(2)', default, 10),('www.animals(3)', default, 10),('www.useimg', default, 11),('www.useimg(1)', default, 11),('www.useimg(2)', default, 11),('www.useimg(3)', default, 11),('www.funnyig', default, 12),('www.funnyig(1)', default, 12),('www.funnyig(2)', default, 12),('www.funnyig(3)', default, 12),('www.darkmemes', default, 13),('www.darkmemes(1)', default, 13),('www.darkmemes(2)', default, 13),('www.darkmemes(3)', default, 13), ('www.memes', default, 14),('www.memes(1)', default, 14),('www.memes(2)', default, 14),('www.memes(3)', default, 14),('www.porn', default, 15), ('www.porn(1)', default, 15),('www.porn(2)', default, 15),('www.porn(3)', default, 15),('www.hentai', default, 16),('www.hentai(1)', default, 16),('www.hentai(2)', default, 16),('www.hentai(3)', default, 16),('www.ffdgdg', default, 17),('www.ffdgdg(1)', default, 17),('www.ffdgdg(2)', default, 17),('www.ffdgdg(3)', default, 17),('www.kjgghg', default, 18),('www.kjgghg(1)', default, 18),('www.kjgghg(2)', default, 18),('www.kjgghg(3)', default, 18),('www.summer1989', default, 19),('www.summer1989(1)', default, 19),('www.summer1989(2)', default, 19),('www.summer1989(3)', default, 19),('www.royallife', default, 20),('www.royallife(1)', default, 20),('www.royallife(2)', default, 20),('www.royallife(3)', default, 20);
insert into messages(message) values
	('Привіт'),#1
    ('Привіт!'),#2
    ('Як спарви?'),#3
    ('Добре, а у тебе?'),#4
    ('Добре'),#5
    ('Погано'),#6
    ('Могло бути й краще'),#7
    ('Вітаю з Новим Роком!!!'),#8
    ('і тебе'),#9
    ('Дякую і тебе'),#10
    ('Що нового в житті?'),#11
    ('Да ось вирішив зайнятися програмуванням'),#12
    ('ООО!'),#13
    ('Це чудово!'),#14
    ('Ну нехай щастить'),#15
    ('Дякую'),#16
    ('Вибач не можу зараз писати'),#17
    ('Зрозумів'),#18
    ('Чому?'),#19
    ('Погнали катку в КС'),#20
    ('Го, я создав'),#21
    ('Мені в бравл старс випала легендарка'),#22
    ('Хочу купити собі бравл пасс'),#23
    ('Ну це корече мені треба бігти'),#24
    ('До побачення'),#25
    ('Пока');#26
insert into send_get_messages (message_id, send_user_id, get_user_id,created_at) values (1,2,6,'2021-01-10 14:54:55'), (2,6,2,'2021-01-10 14:54:56'), (3,2,6,'2021-01-10 14:54:57'),(6,6,2,'2021-01-10 14:54:58'),(19,2,6,'2021-01-10 14:54:59'), (17,6,2,'2021-01-10 14:55:00'), (2,7,4,'2021-01-01 00:04:39'), (8,7,4,'2021-01-01 00:04:59'), (10,4,7,'2021-01-01 00:06:35'), (8,7,9,'2021-01-01 00:06:52'),(9,9,7,'2021-01-01 00:21:13'),(1,1,8,'2021-01-01 00:21:14'),(20,1,8,'2021-01-01 00:21:15'),(13,8,1,'2021-01-01 00:21:16'),(20,1,3,'2021-01-01 00:21:17'),(17,3,1,'2021-01-01 00:21:18'),(22,3,1,'2021-01-01 00:21:19'),(14,1,3,'2021-01-01 00:21:20'),(18,1,3,'2021-01-01 00:21:21'),(15,1,3,'2021-01-01 00:21:22');
insert into likes (photo_id, user_id, created_at) values (1,2,'2021-01-08 08:57:56'), (2,2,'2020-12-31 11:25:22'),(2,3,'2021-01-08 12:57:56'),(4,2,'2020-12-31 11:25:22'),(5,1,'2021-01-08 08:57:56'),(5,2,'2021-01-08 12:57:56'),(5,7,'2020-12-31 11:25:22'),(1,8,'2020-12-31 11:25:22'),(1,4,'2021-01-08 12:57:56'),(6,1,'2020-12-29 16:23:41'),(7,1,'2020-12-29 16:23:41'),(7,9,'2020-12-29 16:23:41'),(12,10,default),(15,6,'2021-01-08 08:57:56'),(15,7,'2020-12-31 11:25:22'),(15,9,'2020-12-31 11:25:22'),(20,1,'2020-12-31 11:25:22'),(20,4,'2021-01-08 12:57:56'),(20,2,default),(20,3,'2021-01-08 12:57:56'),(20,5,'2020-12-29 16:23:41'),(20,6,'2020-12-29 16:23:41'), (25,9,default),(25,1,'2021-01-08 12:57:56'),(25,10,'2020-12-31 11:25:22'),(24,10,'2020-12-31 11:25:22'),(35,2,'2021-01-08 12:57:56'),(35,1,'2020-12-29 16:23:41'),(35,4,'2021-01-08 12:57:56'),(40,5,'2021-01-08 08:57:56'),(41,2,'2020-12-29 16:23:41'),(32,10,'2021-01-08 08:57:56'),(55,9,'2020-12-29 16:23:41'),(45,6,'2020-12-29 16:23:41'),(45,5,'2021-01-08 08:57:56'),(68,7,'2020-12-29 16:23:41'),(61,5,'2021-01-08 12:57:56'),(71,6,'2020-12-29 16:23:41'),(72,3,default),(73,8,'2021-01-08 12:57:56'),(80,9,'2020-12-29 16:23:41'),(64,4,'2020-12-31 11:25:22'),(79,3,'2020-12-29 16:23:41'),(75,3,'2020-12-31 11:25:22'),(42,7,'2020-12-29 16:23:41');
insert into follows (follower_id, followee_id, created_at) values (1,2,default),(2,1,default),(3,1,default),(1,4,default),(4,3,default),(2,5,default),(5,7,default),(5,6,default),(5,8,default),(6,5,default),(8,1,default),(7,4,default),(1,10,default),(10,2,default),(10,3,default),(10,7,default);
insert into comments (comment_text, photo_id, user_id,created_at) values ('Nice!',2,1,default),('Super!',3,4,default),('I Love YOU',20,6,default),('Nice cock!',70,8,default),('Miss you',34,2,default),('ahahhahahaha',16,1,default),('LOL',34,5,default),('Хачу майонеза',68,9,default),('Суету навести ахота',41,5,default),('А где Влад Бумага?',44,7,default),('АХХХАХАХААХАХ',72,3,default),('На твое сообщение пришел новый телефон, важное посмотри вдруг там что-то',42,6,default),('Слава Україні!',55,1,default),('Героям Слава!',55,4,default),('дизлайк отписка',80,8,default),('WOW!!! This is so cute!',45,8,default),('Never mind',75,5,default),('Nicht schlecht',65,7,default),('Ich möchte etwas zu essen',69,4,default),('Das ist gut',72,2,default),('Was ist das? Ist das buch?',25,9,default),('Keine Ahnung',58,9,default),('Ja wohl',63,10,default);