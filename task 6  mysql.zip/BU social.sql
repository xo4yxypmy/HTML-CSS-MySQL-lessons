-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: social_name
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alboms`
--

DROP TABLE IF EXISTS `alboms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alboms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `alboms_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alboms`
--

LOCK TABLES `alboms` WRITE;
/*!40000 ALTER TABLE `alboms` DISABLE KEYS */;
INSERT INTO `alboms` VALUES (1,'Summer 2018','2021-01-10 15:15:03',5),(2,'Winter 2019','2021-01-10 15:15:03',5),(3,'Friends','2021-01-10 15:15:03',1),(4,'Family','2021-01-02 19:45:04',1),(5,'My best friends','2020-12-02 11:54:06',2),(6,'My favorite dog','2021-01-10 15:15:03',2),(7,'Wishes','2021-01-10 15:15:03',3),(8,'Mom`s Birthday','2021-01-10 15:15:03',3),(9,'Nature','2020-10-29 10:12:58',4),(10,'Animals','2020-09-01 02:49:59',4),(11,'Usefull images','2021-01-10 15:15:03',6),(12,'Funny images','2021-01-10 15:15:03',6),(13,'Dark memes','2021-01-10 15:15:03',7),(14,'Memes','2021-01-10 15:15:03',7),(15,'Porn','2021-01-10 15:15:03',8),(16,'Hentai','2021-01-10 15:15:03',8),(17,'ghuirhiuershkjse','2020-11-09 13:54:09',9),(18,'dsgghshtjytjt','2021-01-10 15:15:03',9),(19,'Summer 1989','2019-06-18 13:07:44',10),(20,'Royal life','2021-01-10 15:15:03',10);
/*!40000 ALTER TABLE `alboms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `comment_text` varchar(255) NOT NULL,
  `photo_id` int NOT NULL,
  `user_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `photo_id` (`photo_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`photo_id`) REFERENCES `photos` (`id`),
  CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` VALUES (1,'Nice!',2,1,'2021-01-10 15:15:03'),(2,'Super!',3,4,'2021-01-10 15:15:03'),(3,'I Love YOU',20,6,'2021-01-10 15:15:03'),(4,'Nice cock!',70,8,'2021-01-10 15:15:03'),(5,'Miss you',34,2,'2021-01-10 15:15:03'),(6,'ahahhahahaha',16,1,'2021-01-10 15:15:03'),(7,'LOL',34,5,'2021-01-10 15:15:03'),(8,'Хачу майонеза',68,9,'2021-01-10 15:15:03'),(9,'Суету навести ахота',41,5,'2021-01-10 15:15:03'),(10,'А где Влад Бумага?',44,7,'2021-01-10 15:15:03'),(11,'АХХХАХАХААХАХ',72,3,'2021-01-10 15:15:03'),(12,'На твое сообщение пришел новый телефон, важное посмотри вдруг там что-то',42,6,'2021-01-10 15:15:03'),(13,'Слава Україні!',55,1,'2021-01-10 15:15:03'),(14,'Героям Слава!',55,4,'2021-01-10 15:15:03'),(15,'дизлайк отписка',80,8,'2021-01-10 15:15:03'),(16,'WOW!!! This is so cute!',45,8,'2021-01-10 15:15:03'),(17,'Never mind',75,5,'2021-01-10 15:15:03'),(18,'Nicht schlecht',65,7,'2021-01-10 15:15:03'),(19,'Ich möchte etwas zu essen',69,4,'2021-01-10 15:15:03'),(20,'Das ist gut',72,2,'2021-01-10 15:15:03'),(21,'Was ist das? Ist das buch?',25,9,'2021-01-10 15:15:03'),(22,'Keine Ahnung',58,9,'2021-01-10 15:15:03'),(23,'Ja wohl',63,10,'2021-01-10 15:15:03');
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `follows`
--

DROP TABLE IF EXISTS `follows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `follows` (
  `follower_id` int NOT NULL,
  `followee_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`follower_id`,`followee_id`),
  KEY `followee_id` (`followee_id`),
  CONSTRAINT `follows_ibfk_1` FOREIGN KEY (`follower_id`) REFERENCES `users` (`id`),
  CONSTRAINT `follows_ibfk_2` FOREIGN KEY (`followee_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `follows`
--

LOCK TABLES `follows` WRITE;
/*!40000 ALTER TABLE `follows` DISABLE KEYS */;
INSERT INTO `follows` VALUES (1,2,'2021-01-10 15:15:03'),(1,4,'2021-01-10 15:15:03'),(1,10,'2021-01-10 15:15:03'),(2,1,'2021-01-10 15:15:03'),(2,5,'2021-01-10 15:15:03'),(3,1,'2021-01-10 15:15:03'),(4,3,'2021-01-10 15:15:03'),(5,6,'2021-01-10 15:15:03'),(5,7,'2021-01-10 15:15:03'),(5,8,'2021-01-10 15:15:03'),(6,5,'2021-01-10 15:15:03'),(7,4,'2021-01-10 15:15:03'),(8,1,'2021-01-10 15:15:03'),(10,2,'2021-01-10 15:15:03'),(10,3,'2021-01-10 15:15:03'),(10,7,'2021-01-10 15:15:03');
/*!40000 ALTER TABLE `follows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `likes`
--

DROP TABLE IF EXISTS `likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `likes` (
  `user_id` int NOT NULL,
  `photo_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`,`photo_id`),
  KEY `photo_id` (`photo_id`),
  CONSTRAINT `likes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `likes_ibfk_2` FOREIGN KEY (`photo_id`) REFERENCES `photos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `likes`
--

LOCK TABLES `likes` WRITE;
/*!40000 ALTER TABLE `likes` DISABLE KEYS */;
INSERT INTO `likes` VALUES (1,5,'2021-01-08 06:57:56'),(1,6,'2020-12-29 14:23:41'),(1,7,'2020-12-29 14:23:41'),(1,20,'2020-12-31 09:25:22'),(1,25,'2021-01-08 10:57:56'),(1,35,'2020-12-29 14:23:41'),(2,1,'2021-01-08 06:57:56'),(2,2,'2020-12-31 09:25:22'),(2,4,'2020-12-31 09:25:22'),(2,5,'2021-01-08 10:57:56'),(2,20,'2021-01-10 15:15:03'),(2,35,'2021-01-08 10:57:56'),(2,41,'2020-12-29 14:23:41'),(3,2,'2021-01-08 10:57:56'),(3,20,'2021-01-08 10:57:56'),(3,72,'2021-01-10 15:15:03'),(3,75,'2020-12-31 09:25:22'),(3,79,'2020-12-29 14:23:41'),(4,1,'2021-01-08 10:57:56'),(4,20,'2021-01-08 10:57:56'),(4,35,'2021-01-08 10:57:56'),(4,64,'2020-12-31 09:25:22'),(5,20,'2020-12-29 14:23:41'),(5,40,'2021-01-08 06:57:56'),(5,45,'2021-01-08 06:57:56'),(5,61,'2021-01-08 10:57:56'),(6,15,'2021-01-08 06:57:56'),(6,20,'2020-12-29 14:23:41'),(6,45,'2020-12-29 14:23:41'),(6,71,'2020-12-29 14:23:41'),(7,5,'2020-12-31 09:25:22'),(7,15,'2020-12-31 09:25:22'),(7,42,'2020-12-29 14:23:41'),(7,68,'2020-12-29 14:23:41'),(8,1,'2020-12-31 09:25:22'),(8,73,'2021-01-08 10:57:56'),(9,7,'2020-12-29 14:23:41'),(9,15,'2020-12-31 09:25:22'),(9,25,'2021-01-10 15:15:03'),(9,55,'2020-12-29 14:23:41'),(9,80,'2020-12-29 14:23:41'),(10,12,'2021-01-10 15:15:03'),(10,24,'2020-12-31 09:25:22'),(10,25,'2020-12-31 09:25:22'),(10,32,'2021-01-08 06:57:56');
/*!40000 ALTER TABLE `likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` VALUES (1,'Привіт'),(2,'Привіт!'),(3,'Як спарви?'),(4,'Добре, а у тебе?'),(5,'Добре'),(6,'Погано'),(7,'Могло бути й краще'),(8,'Вітаю з Новим Роком!!!'),(9,'і тебе'),(10,'Дякую і тебе'),(11,'Що нового в житті?'),(12,'Да ось вирішив зайнятися програмуванням'),(13,'ООО!'),(14,'Це чудово!'),(15,'Ну нехай щастить'),(16,'Дякую'),(17,'Вибач не можу зараз писати'),(18,'Зрозумів'),(19,'Чому?'),(20,'Погнали катку в КС'),(21,'Го, я создав'),(22,'Мені в бравл старс випала легендарка'),(23,'Хочу купити собі бравл пасс'),(24,'Ну це корече мені треба бігти'),(25,'До побачення'),(26,'Пока');
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `photos`
--

DROP TABLE IF EXISTS `photos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `photos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `photo_url` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `albom_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `albom_id` (`albom_id`),
  CONSTRAINT `photos_ibfk_1` FOREIGN KEY (`albom_id`) REFERENCES `alboms` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `photos`
--

LOCK TABLES `photos` WRITE;
/*!40000 ALTER TABLE `photos` DISABLE KEYS */;
INSERT INTO `photos` VALUES (1,'www.summerfoto2018','2021-01-10 15:15:03',1),(2,'www.summerfoto2018(1)','2021-01-10 15:15:03',1),(3,'www.summerfoto2018(2)','2021-01-10 15:15:03',1),(4,'www.summerfoto2018(3)','2021-01-10 15:15:03',1),(5,'www.winterfoto2019','2021-01-10 15:15:03',2),(6,'www.winterfoto2019(1)','2021-01-10 15:15:03',2),(7,'www.winterfoto2019(2)','2021-01-10 15:15:03',2),(8,'www.winterfoto2019(3)','2021-01-10 15:15:03',2),(9,'www.friends','2021-01-10 15:15:03',3),(10,'www.friends(1)','2021-01-10 15:15:03',3),(11,'www.friends(2)','2021-01-10 15:15:03',3),(12,'www.friends(3)','2021-01-10 15:15:03',3),(13,'www.family','2021-01-10 15:15:03',4),(14,'www.family(1)','2021-01-10 15:15:03',4),(15,'www.family(2)','2021-01-10 15:15:03',4),(16,'www.family(3)','2021-01-10 15:15:03',4),(17,'www.mybf','2021-01-10 15:15:03',5),(18,'www.mybf(1)','2021-01-10 15:15:03',5),(19,'www.mybf(2)','2021-01-10 15:15:03',5),(20,'www.mybf(3)','2021-01-10 15:15:03',5),(21,'www.myfd','2021-01-10 15:15:03',6),(22,'www.myfd(1)','2021-01-10 15:15:03',6),(23,'www.myfd(2)','2021-01-10 15:15:03',6),(24,'www.myfd(3)','2021-01-10 15:15:03',6),(25,'www.wishes','2021-01-10 15:15:03',7),(26,'www.wishes(1)','2021-01-10 15:15:03',7),(27,'www.wishes(2)','2021-01-10 15:15:03',7),(28,'www.wishes(3)','2021-01-10 15:15:03',7),(29,'www.momsbd','2021-01-10 15:15:03',8),(30,'www.momsbd(1)','2021-01-10 15:15:03',8),(31,'www.momsbd(2)','2021-01-10 15:15:03',8),(32,'www.momsbd(3)','2021-01-10 15:15:03',8),(33,'www.nature','2021-01-10 15:15:03',9),(34,'www.nature(1)','2021-01-10 15:15:03',9),(35,'www.nature(2)','2021-01-10 15:15:03',9),(36,'www.nature(3)','2021-01-10 15:15:03',9),(37,'www.animals','2021-01-10 15:15:03',10),(38,'www.animals(1)','2021-01-10 15:15:03',10),(39,'www.animals(2)','2021-01-10 15:15:03',10),(40,'www.animals(3)','2021-01-10 15:15:03',10),(41,'www.useimg','2021-01-10 15:15:03',11),(42,'www.useimg(1)','2021-01-10 15:15:03',11),(43,'www.useimg(2)','2021-01-10 15:15:03',11),(44,'www.useimg(3)','2021-01-10 15:15:03',11),(45,'www.funnyig','2021-01-10 15:15:03',12),(46,'www.funnyig(1)','2021-01-10 15:15:03',12),(47,'www.funnyig(2)','2021-01-10 15:15:03',12),(48,'www.funnyig(3)','2021-01-10 15:15:03',12),(49,'www.darkmemes','2021-01-10 15:15:03',13),(50,'www.darkmemes(1)','2021-01-10 15:15:03',13),(51,'www.darkmemes(2)','2021-01-10 15:15:03',13),(52,'www.darkmemes(3)','2021-01-10 15:15:03',13),(53,'www.memes','2021-01-10 15:15:03',14),(54,'www.memes(1)','2021-01-10 15:15:03',14),(55,'www.memes(2)','2021-01-10 15:15:03',14),(56,'www.memes(3)','2021-01-10 15:15:03',14),(57,'www.porn','2021-01-10 15:15:03',15),(58,'www.porn(1)','2021-01-10 15:15:03',15),(59,'www.porn(2)','2021-01-10 15:15:03',15),(60,'www.porn(3)','2021-01-10 15:15:03',15),(61,'www.hentai','2021-01-10 15:15:03',16),(62,'www.hentai(1)','2021-01-10 15:15:03',16),(63,'www.hentai(2)','2021-01-10 15:15:03',16),(64,'www.hentai(3)','2021-01-10 15:15:03',16),(65,'www.ffdgdg','2021-01-10 15:15:03',17),(66,'www.ffdgdg(1)','2021-01-10 15:15:03',17),(67,'www.ffdgdg(2)','2021-01-10 15:15:03',17),(68,'www.ffdgdg(3)','2021-01-10 15:15:03',17),(69,'www.kjgghg','2021-01-10 15:15:03',18),(70,'www.kjgghg(1)','2021-01-10 15:15:03',18),(71,'www.kjgghg(2)','2021-01-10 15:15:03',18),(72,'www.kjgghg(3)','2021-01-10 15:15:03',18),(73,'www.summer1989','2021-01-10 15:15:03',19),(74,'www.summer1989(1)','2021-01-10 15:15:03',19),(75,'www.summer1989(2)','2021-01-10 15:15:03',19),(76,'www.summer1989(3)','2021-01-10 15:15:03',19),(77,'www.royallife','2021-01-10 15:15:03',20),(78,'www.royallife(1)','2021-01-10 15:15:03',20),(79,'www.royallife(2)','2021-01-10 15:15:03',20),(80,'www.royallife(3)','2021-01-10 15:15:03',20);
/*!40000 ALTER TABLE `photos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `send_get_messages`
--

DROP TABLE IF EXISTS `send_get_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `send_get_messages` (
  `send_user_id` int NOT NULL,
  `get_user_id` int NOT NULL,
  `message_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`send_user_id`,`get_user_id`,`message_id`),
  KEY `get_user_id` (`get_user_id`),
  KEY `message_id` (`message_id`),
  CONSTRAINT `send_get_messages_ibfk_1` FOREIGN KEY (`send_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `send_get_messages_ibfk_2` FOREIGN KEY (`get_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `send_get_messages_ibfk_3` FOREIGN KEY (`message_id`) REFERENCES `messages` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `send_get_messages`
--

LOCK TABLES `send_get_messages` WRITE;
/*!40000 ALTER TABLE `send_get_messages` DISABLE KEYS */;
INSERT INTO `send_get_messages` VALUES (1,3,14,'2020-12-31 22:21:20'),(1,3,15,'2020-12-31 22:21:22'),(1,3,18,'2020-12-31 22:21:21'),(1,3,20,'2020-12-31 22:21:17'),(1,8,1,'2020-12-31 22:21:14'),(1,8,20,'2020-12-31 22:21:15'),(2,6,1,'2021-01-10 12:54:55'),(2,6,3,'2021-01-10 12:54:57'),(2,6,19,'2021-01-10 12:54:59'),(3,1,17,'2020-12-31 22:21:18'),(3,1,22,'2020-12-31 22:21:19'),(4,7,10,'2020-12-31 22:06:35'),(6,2,2,'2021-01-10 12:54:56'),(6,2,6,'2021-01-10 12:54:58'),(6,2,17,'2021-01-10 12:55:00'),(7,4,2,'2020-12-31 22:04:39'),(7,4,8,'2020-12-31 22:04:59'),(7,9,8,'2020-12-31 22:06:52'),(8,1,13,'2020-12-31 22:21:16'),(9,7,9,'2020-12-31 22:21:13');
/*!40000 ALTER TABLE `send_get_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nick_name` varchar(40) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nick_name` (`nick_name`),
  KEY `idx_nick_name` (`nick_name`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Unga-Bunga69','2021-01-10 15:15:03'),(2,'Akukaracha','2021-01-10 15:15:03'),(3,'Barak Obama','2020-04-15 13:25:59'),(4,'Unkown user 0023','2021-01-10 15:15:03'),(5,'Hausemaster','2021-01-04 00:39:01'),(6,'Jordan2004','2021-01-10 15:15:03'),(7,'Akuna-Matata','2021-01-10 15:15:03'),(8,'-MyXa_B_KeDaX-','2021-01-10 15:15:03'),(9,'True_Minecrafter','2020-01-02 16:45:19'),(10,'Pink_Pony228','2020-01-04 08:45:49');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-01-10 18:26:31
